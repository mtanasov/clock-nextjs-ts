import React from 'react';
import { useState } from 'react';
import { array_1, array_2 } from "./data/array"

console.log(array_1);
console.log(Array.isArray(array_2));

export const ExampleComponent = () => {
  const [mainArray, setMainArray] = useState(array_1)
  const [selectAr, setSelectAr] = useState([...array_2])

  return (
    <>
      <div>mainArray</div>
      {
        mainArray.map((item: string, index: number) => {
          return <div>
            <button
              style={{
                width: "100px",
                height: "30px"
              }}
              onClick={() => { setSelectAr([...selectAr].concat([item])) }}>
              {item}
            </button>
          </div>
        })
      }

      <div>selectArray</div>
      {
        Array.isArray(selectAr)
          ? selectAr.map((item: string, index: number) => {
            console.log("selectAr", selectAr);
            console.log("selectAr", Array.isArray(selectAr));
            return (
              <div key={index}>
                {item}
              </div>

            )
          })
          : console.error("!!!!!!!!")
      }
    </>
  )
}