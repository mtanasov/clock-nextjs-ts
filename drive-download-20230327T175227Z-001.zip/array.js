export const array_1 = ["google", "joom", "dodge"]

export const array_2 = [];